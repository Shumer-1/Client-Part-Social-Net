export interface News
{
  "info": string,
  "author_id": number,
  "date": string
}
